
function mouseOver() {
    document.getElementById("myCircle").style.opacity = "0.8";
}
function mouseOut() {
  document.getElementById("myCircle").style.opacity = "0.5";
}

function colorRed(id){
    $("#"+id).css("fill","#009688");
}

function colorBlack(id){
    $("#"+id).css("fill","black");
}
//1
function changeColor1(){
   if(document.getElementById("1").style.fill != "#009688"){
   	document.getElementById("1").style.fill="#009688";
       $("#1").css("fill","#009688");
       console.log("filling");
       //myCircle.setAttributeNS(null, "fill", "green");
    }else{
    document.getElementById("1").style.fill="black";
       console.log("also goes");
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver1() {
    document.getElementById("1").style.opacity = "0.8";
}
function mouseOut1() {
  document.getElementById("1").style.opacity = "0.5";
}

//2
function changeColor2(){
   if(document.getElementById("2").style.fill != "#009688"){
    document.getElementById("2").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("2").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver2() {
    document.getElementById("2").style.opacity = "0.8";
}
function mouseOut2() {
  document.getElementById("2").style.opacity = "0.5";
}


//3
function changeColor3(){
   if(document.getElementById("3").style.fill != "#009688"){
    document.getElementById("3").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("3").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver3() {
    document.getElementById("3").style.opacity = "0.8";
}
function mouseOut3() {
  document.getElementById("3").style.opacity = "0.5";
}

//4
function changeColor4(){
   if(document.getElementById("4").style.fill != "#009688"){
    document.getElementById("4").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("4").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver4() {
    document.getElementById("4").style.opacity = "0.8";
}
function mouseOut4() {
  document.getElementById("4").style.opacity = "0.5";
}

//5
function changeColor5(){
   if(document.getElementById("5").style.fill != "#009688"){
    document.getElementById("5").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("5").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver5() {
    document.getElementById("5").style.opacity = "0.8";
}
function mouseOut5() {
  document.getElementById("5").style.opacity = "0.5";
}

//6
function changeColor6(){
   if(document.getElementById("6").style.fill != "#009688"){
    document.getElementById("6").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("6").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver6() {
    document.getElementById("6").style.opacity = "0.8";
}
function mouseOut6() {
  document.getElementById("6").style.opacity = "0.5";
}

//7
function changeColor7(){
   if(document.getElementById("7").style.fill != "#009688"){
    document.getElementById("7").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("7").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver7() {
    document.getElementById("7").style.opacity = "0.8";
}
function mouseOut7() {
  document.getElementById("7").style.opacity = "0.5";
}

//8
function changeColor8(){
   if(document.getElementById("8").style.fill != "#009688"){
    document.getElementById("8").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("8").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver8() {
    document.getElementById("8").style.opacity = "0.8";
}
function mouseOut8() {
  document.getElementById("8").style.opacity = "0.5";
}

//9
function changeColor9(){
   if(document.getElementById("9").style.fill != "#009688"){
    document.getElementById("9").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("9").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver9() {
    document.getElementById("9").style.opacity = "0.8";
}
function mouseOut9() {
  document.getElementById("9").style.opacity = "0.5";
}

//10
function changeColor10(){
   if(document.getElementById("10").style.fill != "#009688"){
    document.getElementById("10").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("10").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver10() {
    document.getElementById("10").style.opacity = "0.8";
}
function mouseOut10() {
  document.getElementById("10").style.opacity = "0.5";
}

//11
function changeColor11(){
   if(document.getElementById("11").style.fill != "#009688"){
    document.getElementById("11").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("11").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver11() {
    document.getElementById("11").style.opacity = "0.8";
}
function mouseOut11() {
  document.getElementById("11").style.opacity = "0.5";
}

//12
function changeColor12(){
   if(document.getElementById("12").style.fill != "#009688"){
    document.getElementById("12").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("12").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver12() {
    document.getElementById("12").style.opacity = "0.8";
}
function mouseOut12() {
  document.getElementById("12").style.opacity = "0.5";
}

//13
function changeColor13(){
   if(document.getElementById("13").style.fill != "#009688"){
    document.getElementById("13").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("13").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver13() {
    document.getElementById("13").style.opacity = "0.8";
}
function mouseOut13() {
  document.getElementById("13").style.opacity = "0.5";
}

//14
function changeColor14(){
   if(document.getElementById("14").style.fill != "#009688"){
    document.getElementById("14").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("14").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver14() {
    document.getElementById("14").style.opacity = "0.8";
}
function mouseOut14() {
  document.getElementById("14").style.opacity = "0.5";
}

//15
function changeColor15(){
   if(document.getElementById("15").style.fill != "#009688"){
    document.getElementById("15").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("15").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver15() {
    document.getElementById("15").style.opacity = "0.8";
}
function mouseOut15() {
  document.getElementById("15").style.opacity = "0.5";
}

//16
function changeColor16(){
   if(document.getElementById("16").style.fill != "#009688"){
    document.getElementById("16").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("16").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver16() {
    document.getElementById("16").style.opacity = "0.8";
}
function mouseOut16() {
  document.getElementById("16").style.opacity = "0.5";
}

//17
function changeColor17(){
   if(document.getElementById("17").style.fill != "#009688"){
    document.getElementById("17").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("17").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver17() {
    document.getElementById("17").style.opacity = "0.8";
}
function mouseOut17() {
  document.getElementById("17").style.opacity = "0.5";
}

//18
function changeColor18(){
   if(document.getElementById("18").style.fill != "#009688"){
    document.getElementById("18").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("18").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver18() {
    document.getElementById("18").style.opacity = "0.8";
}
function mouseOut18() {
  document.getElementById("18").style.opacity = "0.5";
}

//19
function changeColor19(){
   if(document.getElementById("19").style.fill != "#009688"){
    document.getElementById("19").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("19").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver19() {
    document.getElementById("19").style.opacity = "0.8";
}
function mouseOut19() {
  document.getElementById("19").style.opacity = "0.5";
}

//20
function changeColor20(){
   if(document.getElementById("20").style.fill != "#009688"){
    document.getElementById("20").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("20").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver20() {
    document.getElementById("20").style.opacity = "0.8";
}
function mouseOut20() {
  document.getElementById("20").style.opacity = "0.5";
}

//21
function changeColor21(){
   if(document.getElementById("21").style.fill != "#009688"){
    document.getElementById("21").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("21").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver21() {
    document.getElementById("21").style.opacity = "0.8";
}
function mouseOut21() {
  document.getElementById("21").style.opacity = "0.5";
}

//22
function changeColor22(){
   if(document.getElementById("22").style.fill != "#009688"){
    document.getElementById("22").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("22").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver22() {
    document.getElementById("22").style.opacity = "0.8";
}
function mouseOut22() {
  document.getElementById("22").style.opacity = "0.5";
}

//23
function changeColor23(){
   if(document.getElementById("23").style.fill != "#009688"){
    document.getElementById("23").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("23").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver23() {
    document.getElementById("23").style.opacity = "0.8";
}
function mouseOut23() {
  document.getElementById("23").style.opacity = "0.5";
}

//24
function changeColor24(){
   if(document.getElementById("24").style.fill != "#009688"){
    document.getElementById("24").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("24").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver24() {
    document.getElementById("24").style.opacity = "0.8";
}
function mouseOut24() {
  document.getElementById("24").style.opacity = "0.5";
}

//25
function changeColor25(){
   if(document.getElementById("25").style.fill != "#009688"){
    document.getElementById("25").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("25").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver25() {
    document.getElementById("25").style.opacity = "0.8";
}
function mouseOut25() {
  document.getElementById("25").style.opacity = "0.5";
}

//26
function changeColor26(){
   if(document.getElementById("26").style.fill != "#009688"){
    document.getElementById("26").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("26").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver26() {
    document.getElementById("26").style.opacity = "0.8";
}
function mouseOut26() {
  document.getElementById("26").style.opacity = "0.5";
}

//27
function changeColor27(){
   if(document.getElementById("27").style.fill != "#009688"){
    document.getElementById("27").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("27").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver27() {
    document.getElementById("27").style.opacity = "0.8";
}
function mouseOut27() {
  document.getElementById("27").style.opacity = "0.5";
}

//28
function changeColor28(){
   if(document.getElementById("28").style.fill != "#009688"){
    document.getElementById("28").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("28").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver28() {
    document.getElementById("28").style.opacity = "0.8";
}
function mouseOut28() {
  document.getElementById("28").style.opacity = "0.5";
}

//29
function changeColor29(){
   if(document.getElementById("29").style.fill != "#009688"){
    document.getElementById("29").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("29").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver29() {
    document.getElementById("29").style.opacity = "0.8";
}
function mouseOut29() {
  document.getElementById("29").style.opacity = "0.5";
}

//30
function changeColor30(){
   if(document.getElementById("30").style.fill != "#009688"){
    document.getElementById("30").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("30").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver30() {
    document.getElementById("30").style.opacity = "0.8";
}
function mouseOut30() {
  document.getElementById("30").style.opacity = "0.5";
}

//31
function changeColor31(){
   if(document.getElementById("31").style.fill != "#009688"){
    document.getElementById("31").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("31").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver31() {
    document.getElementById("31").style.opacity = "0.8";
}
function mouseOut31() {
  document.getElementById("31").style.opacity = "0.5";
}

//32
function changeColor32(){
   if(document.getElementById("32").style.fill != "#009688"){
    document.getElementById("32").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("32").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver32() {
    document.getElementById("32").style.opacity = "0.8";
}
function mouseOut32() {
  document.getElementById("32").style.opacity = "0.5";
}

//33
function changeColor33(){
   if(document.getElementById("33").style.fill != "#009688"){
    document.getElementById("33").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("33").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver33() {
    document.getElementById("33").style.opacity = "0.8";
}
function mouseOut33() {
  document.getElementById("33").style.opacity = "0.5";
}

//34
function changeColor34(){
   if(document.getElementById("34").style.fill != "#009688"){
    document.getElementById("34").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("34").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver34() {
    document.getElementById("34").style.opacity = "0.8";
}
function mouseOut34() {
  document.getElementById("34").style.opacity = "0.5";
}

//35
function changeColor35(){
   if(document.getElementById("35").style.fill != "#009688"){
    document.getElementById("35").style.fill="#009688";
    //myCircle.setAttributeNS(null, "fill", "green");
    }
    else{
    document.getElementById("35").style.fill="black";
    //myCircle.setAttributeNS(null, "fill", "#009688");
    }
}
function mouseOver35() {
    document.getElementById("35").style.opacity = "0.8";
}
function mouseOut35() {
  document.getElementById("35").style.opacity = "0.5";
}





